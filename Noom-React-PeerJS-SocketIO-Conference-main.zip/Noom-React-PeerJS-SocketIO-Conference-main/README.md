# Noom-React-PeerJS-SocketIO-Conference

An LMS Project | A video conference application | Zoom clone

# Demo

<p float="left">
<img src="https://github.com/ConfidenceDev/Noom-React-PeerJS-SocketIO-Conference/blob/main/src/assets/demo.png" width="900" alt="demo">
</p>

# How to Use

- Clone or download zip file and extract
- Install packages `npm install`
- Run React App: `npm run dev` or `npm run start`
- Run Server: `npm run server`
